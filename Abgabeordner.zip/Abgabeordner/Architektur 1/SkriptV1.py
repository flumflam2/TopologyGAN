


get_ipython().run_line_magic('matplotlib', 'inline')
get_ipython().run_line_magic('matplotlib', 'notebook')


# In[18]:

# Standard-Module für Dateioperationen und Systemeinstellungen importieren.
import glob                   # Zum Auffinden von Dateien anhand von Mustern
import sys                    # Systembezogene Parameter und Funktionen
import numpy                 # Numerische Operationen

# PyTorch-Module für Tensorberechnungen und Deep Learning importieren.
import torch                  # Hauptpaket von PyTorch
import torch.nn as nn         # Modul für neuronale Netzwerke
import torch.nn.parallel      # Für parallele Verarbeitung in neuronalen Netzwerken
import torch.optim as optim   # Optimierungsalgorithmen
import torch.utils.data       # Datenladehilfsmittel
from torch_scatter import scatter_mean   # Scatter-Operationen zur Aggregation von Tensor-Daten
from torch_geometric.nn import GCNConv     # Graph Convolutional Network Schicht von torch_geometric
import torch.nn.functional as F            # Funktionale Schnittstelle für neuronale Netzoperationen
from torch.utils.data import Dataset, DataLoader  # Dataset- und DataLoader-Klassen

# Matplotlib für die Visualisierung importieren.
import matplotlib.pyplot as plt

# SciPy für rechnerische Geometrie (Delaunay-Triangulation) importieren.
from scipy.spatial import Delaunay

# PyTorch3D-Module für 3D-Datenverarbeitung und Verlustfunktionen importieren.
from pytorch3d.loss import mesh_normal_consistency
from pytorch3d.loss import chamfer_distance
from pytorch3d.ops import sample_points_from_meshes
from pytorch3d.structures import Meshes
from pytorch3d.io import load_obj, save_obj
from pytorch3d.datasets import collate_batched_meshes

# PyTorch-Version und CUDA-Verfügbarkeit zur Kontrolle ausgeben.
print("PyTorch Version:", torch.__version__)
print("CUDA Verfügbar:", torch.cuda.is_available())

# Standardgerät auf CUDA setzen (für GPU-Beschleunigung).
device = "cuda"
torch.set_default_device(device)

# Numpy so einstellen, dass ganze Arrays ausgegeben werden.
numpy.set_printoptions(threshold=sys.maxsize)

# Lokales DGCNN-Modell importieren.
from dgcnn_model import DGCNN


# Daten
# =====

# In[20]:

# Benutzerdefiniertes Dataset zum Laden von 3D-Objektdateien aus dem Ordner "FusionDataset".
class FusionDataset(Dataset):
    def __init__(self, transform=None, target_transform=None):
        # Pfad, in dem die .obj-Dateien gespeichert sind.
        self.objs_path = "FusionDataset/"
        self.data = []
        # Alle .obj-Dateien im Ordner mit glob finden.
        for obj_path in glob.glob(self.objs_path + "*.obj"):   
            self.data.append([obj_path])   
            
    def __len__(self):
        # Rückgabe der Anzahl der gefundenen Objekte.
        return len(self.data)

    def __getitem__(self, idx):
        # Wörterbuch zur Speicherung der Modelldaten.
        model = {}
        
        # Den Pfad zur Objektdatei für den gegebenen Index abrufen.
        obj_path = self.data[idx]
        
        # Die .obj-Datei mit der load_obj-Funktion von PyTorch3D laden.
        verts, faces, aux = load_obj(obj_path[0], device=device)
        faces_idx = faces.verts_idx.to(device)  # Face-Indizes auf das gewählte Gerät übertragen.
        verts = verts.to(device)                # Vertices auf das gewählte Gerät übertragen.
        # Ein Meshes-Objekt aus den Vertices und Faces erstellen.
        trg_mesh = Meshes(verts=[verts], faces=[faces_idx]).to(device)
        model["verts"] = verts
        model["faces"] = faces_idx
       
        return model


# Face-Generator
# ==============
# Diese Funktion konvertiert eine Batch von Punktwolken in eine Batch von PyTorch3D-Meshes.
# In[21]:

def face_generator(point_clouds):
    """
    Konvertiere eine Batch von Punktwolken in eine Batch von PyTorch3D-Meshes.
    
    Args:
        point_clouds: Tensor der Form (batch_size, num_points, 3), der die Punktwolken enthält.
    
    Returns:
        meshes: PyTorch3D Meshes-Objekt, das die Batch an Meshes enthält.
    """
    batch_size = point_clouds.size(0)
    verts_list = []  # Liste für Vertices (pro Mesh)
    faces_list = []  # Liste für Faces (pro Mesh)
    
    for i in range(batch_size):
        # Die Punktwolke in ein NumPy-Array konvertieren (für SciPy).
        points = point_clouds[i].cpu().detach().numpy()
        
        # Delaunay-Triangulation durchführen, um Faces zu erzeugen.
        tri = Delaunay(points)

        # Vertices und Faces aus der Triangulation extrahieren.
        verts = torch.tensor(tri.points, dtype=torch.float32).to(point_clouds.device)  # Form: (num_vertices, 3)
        faces = torch.tensor(tri.convex_hull, dtype=torch.int64).to(point_clouds.device)  # Form: (num_faces, 3)

        # Ungültige Faces (mit -1) herausfiltern.
        valid_faces = faces[(faces >= 0).all(dim=1)]  

        # Die gültigen Vertices und Faces in den Listen speichern.
        verts_list.append(verts)
        faces_list.append(valid_faces)
        
    # Ein Meshes-Objekt aus den gesammelten Vertices und Faces erstellen.
    meshes = Meshes(verts=verts_list, faces=faces_list).to(point_clouds.device)
    return {"mesh": meshes, "verts": verts_list, "faces": faces_list}


# Edge Index Generator
# ====================
# Diese Funktion erzeugt einen eindeutigen Satz von Kanten aus den Face-Daten.
# In[23]:

def edge_index_generator(faces):
   # Kanten aus jedem Face (jedes Face trägt 3 Kanten) zusammenfügen.
   edges = torch.cat([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]], dim=0)
   edges = torch.sort(edges, dim=1)[0]  # Jede Kante sortieren, um eine konsistente Reihenfolge zu gewährleisten.
   # Doppelte Kanten entfernen und transponieren, um die Form (2, num_edges) zu erhalten.
   edge_index = torch.unique(edges, dim=0).T 
   edge_index = edge_index.to(torch.int64)
   return edge_index


# Generator
# =========
# Das Generator-Netzwerk erzeugt Mesh-Vertices aus latenten Vektoren und extrahierten Features.
# In[24]:

class MeshGenerator(nn.Module):
    def __init__(self, latent_dim, num_vertices, feature_dim):
        """
        Args:
            feature_dim: Dimension der Punkt-Features (z. B. 512 von DGCNN).
            num_vertices: Anzahl der Vertices im generierten Mesh.
            latent_dim: Dimension des latenten Vektors nach Aggregation der Punkt-Features.
        """
        super(MeshGenerator, self).__init__()

        # Aggregation der Punkt-Features zu globalen Features mittels max pooling.
        self.global_pool = nn.AdaptiveMaxPool1d(1)  # Für globales max-pooling

        # Fully-Connected-Schichten zur Transformation der globalen Features und des latenten Vektors in Vertex-Positionen.
        self.fc1 = nn.Linear(feature_dim + latent_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, num_vertices * 3) 

    def forward(self, features, z):
        """
        Args:
            features: Tensor der Form (Batch, Features pro Punkt, Anzahl Punkte).
            z: Latenter Vektor.
        Returns:
            generated_meshes: Ein Dictionary, das das generierte Mesh sowie zugehörige Vertices und Faces enthält.
        """
        batch_size = features.size(0)

        # Schritt 1: Aggregation der Punkt-Features (Globale Features)
        global_features = self.global_pool(features)  # Form: (Batch, Features pro Punkt, 1)
        global_features = global_features.squeeze(-1)   # Form: (Batch, Features pro Punkt)

        # Kombination der globalen Features mit dem latenten Vektor.
        combined_features = torch.cat([global_features, z.detach()], dim=1)
        
        # Schritt 2: Transformation zu einer latenten Repräsentation mittels Fully-Connected-Schichten.
        latent_vector = F.relu(self.fc1(combined_features))  # Form: (Batch, 256)
        latent_vector = F.relu(self.fc2(latent_vector))        # Form: (Batch, 256)

        # Schritt 3: Generierung der Mesh-Vertices.
        vertices = self.fc3(latent_vector)  # Form: (Batch, num_vertices * 3)
        vertices = vertices.view(batch_size, -1, 3)  # Umformen zu (Batch, num_vertices, 3)

        # Erzeugen des Meshes mit der Funktion face_generator.
        generated_meshes = face_generator(vertices.detach().clone())
        return generated_meshes


# Diskriminator
# ============
# Das Diskriminator-Netzwerk unterscheidet zwischen realen und generierten Meshes.
# In[25]:

class MeshDiscriminator(nn.Module):
    def __init__(self, feature_dim, global_feat_dim=1024):
        """
        Args:
            feature_dim: Dimension der Punkt-Features (z. B. 512 von DGCNN).
            global_feat_dim: Dimension des globalen Features, das die gesamte Punktwolke repräsentiert.
        """
        super(MeshDiscriminator, self).__init__()

        # Verarbeitung der Mesh-Vertices mit einer PointNet-ähnlichen Architektur.
        self.conv1_verts = nn.Conv1d(3, 64, kernel_size=1)
        self.conv2_verts = nn.Conv1d(64, 128, kernel_size=1)
        self.conv3_verts = nn.Conv1d(128, global_feat_dim, kernel_size=1)

        # Verarbeitung der extrahierten Punkt-Features.
        self.conv1_feats = nn.Conv1d(feature_dim, 128, kernel_size=1)
        self.conv2_feats = nn.Conv1d(128, 256, kernel_size=1)
        self.conv3_feats = nn.Conv1d(256, global_feat_dim, kernel_size=1)

        # Fully-Connected-Schichten zur Klassifikation (kombinierte globale Features).
        self.fc1 = nn.Linear(2 * global_feat_dim, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 1)  # Finaler Score (zwischen 0 und 1)

    def forward(self, verts, features):
        """
        Args:
            verts: Tensor der Form (Batch, Verts, 3) – die Vertices des Meshes.
            features: Tensor der Form (Batch, Features pro Punkt, Punkte) – extrahierte Form-Features.
        Returns:
            form_score: Tensor der Form (Batch, 1), der die Formqualität bewertet.
        """
        batch_size = verts.size(0)

        # Verarbeitung der Mesh-Vertices:
        verts = verts.permute(0, 2, 1)  # Dimensionen ändern zu (Batch, 3, Verts)
        x_verts = F.relu(self.conv1_verts(verts))  # Ausgabe: (Batch, 64, Verts)
        x_verts = F.relu(self.conv2_verts(x_verts))  # Ausgabe: (Batch, 128, Verts)
        x_verts = F.relu(self.conv3_verts(x_verts))  # Ausgabe: (Batch, global_feat_dim, Verts)
        global_verts = torch.max(x_verts, dim=2)[0]  # Globales Maximum-Pooling über die Vertices

        # Verarbeitung der Punkt-Features:
        x_feats = F.relu(self.conv1_feats(features))  # Ausgabe: (Batch, 128, Points)
        x_feats = F.relu(self.conv2_feats(x_feats))     # Ausgabe: (Batch, 256, Points)
        x_feats = F.relu(self.conv3_feats(x_feats))     # Ausgabe: (Batch, global_feat_dim, Points)
        global_feats = torch.max(x_feats, dim=2)[0]       # Globales Maximum-Pooling über die Punkte

        # Kombination der globalen Informationen aus Vertices und Features.
        combined_features = torch.cat([global_verts, global_feats], dim=1)  # Form: (Batch, 2 * global_feat_dim)

        # Klassifikation der kombinierten Informationen mittels Fully-Connected-Schichten.
        x = F.relu(self.fc1(combined_features))
        x = F.relu(self.fc2(x))
        form_score = torch.sigmoid(self.fc3(x))  # Sigmoid-Aktivierung, um einen Score zwischen 0 und 1 zu erhalten.

        return form_score


# Feature-Modell
# ==============
# Dieser Abschnitt initialisiert und lädt ein vortrainiertes DGCNN-Modell zur Feature-Extraktion.

# In[ ]:

# Eine einfache Arguments-Klasse definieren, um Hyperparameter für das DGCNN-Modell zu speichern.
class Args:
    def __init__(self):
        self.k = 20
        self.emb_dims = 128
        self.dropout = 0.5
        self.num_classes = None  # Irrelevant für die Feature-Extraktion

# Eine Instanz von Args erstellen.
args = Args()

# Das DGCNN-Feature-Modell initialisieren und auf das gewählte Gerät übertragen.
feature_model = DGCNN(args).to(device)

# Vortrainierte Gewichte für das Feature-Modell laden.
pretrained_weights_path = r"C:\Users\Ben\Desktop\MA_PyTorch\dgcnn\pytorch\pretrained\model.1024.t7"
feature_model.load_state_dict(torch.load(pretrained_weights_path), strict=False)

# Das Feature-Modell in den Evaluierungsmodus setzen.
feature_model.eval()


# Training
# =========
# Dieser Abschnitt legt Trainingsparameter fest, initialisiert Generator und Diskriminator
# und führt die Trainingsschleife aus.

# In[ ]:

# Trainings-Hyperparameter setzen.
latent_dim = 128   # Dimension des latenten Vektors
num_epochs = 200   # Anzahl der Trainingsepochen
batch_size = 32    # Batch-Größe
N = 1024           # (Wird im Code nicht verwendet, Platzhalter)
lr = 0.0002        # Lernrate
feature_dim = 512  # Dimension der extrahierten Features (z. B. von DGCNN)
num_verts = 32     # Anzahl der Vertices im generierten Mesh

# Hinweis: num_vertices sollte möglichst nah an realen Objekten liegen.
# (Zum Testen: num_vertices = Vertices in Sphere)

# Initialisierung von Generator und Diskriminator.
generator = MeshGenerator(latent_dim=latent_dim, num_vertices=num_verts, feature_dim=feature_dim)
discriminator = MeshDiscriminator(feature_dim)

# Modelle auf das gewählte Gerät (GPU) übertragen.
generator = generator.to(device)
discriminator = discriminator.to(device)

# Optimizer für Generator und Diskriminator mit Adam einrichten.
optimizer_G = optim.Adam(generator.parameters(), lr=lr*4, betas=(0.5, 0.999))
optimizer_D = optim.Adam(discriminator.parameters(), lr=lr, betas=(0.5, 0.999))

# Dataset und DataLoader initialisieren.
dataset = FusionDataset()
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle="true", 
                        collate_fn=collate_batched_meshes, 
                        generator=torch.Generator(device=device))

print("Starting training...")

# Trainingsschleife
for epoch in range(num_epochs):
    
    # Einen Batch aus dem DataLoader abrufen.
    # (Alternativ kann hier ein Schleifeniterator verwendet werden.)
    real_meshes = next(iter(dataloader))    
    print("Loading batch..")
    
    # -----------------
    # Training des Diskriminators
    # -----------------
    optimizer_D.zero_grad()  # Setzt die Gradienten des Diskriminators auf Null.
   
    # Schritt 1: Reale Daten durch den Diskriminator verarbeiten.
    point_clouds = sample_points_from_meshes(real_meshes["mesh"], num_samples=num_verts).to(device)
    
    # Dimensionsanpassung, damit das Format den Erwartungen entspricht.
    point_clouds = point_clouds.permute(0, 2, 1)
    
    # Features mit dem vortrainierten DGCNN-Feature-Modell extrahieren.
    input_features = feature_model(point_clouds).to(device)
    features_min = input_features.min(dim=1, keepdim=True)[0]  # Minimum über Dimension 1
    features_min = features_min.min(dim=2, keepdim=True)[0]      # Minimum über Dimension 2
    features_max = input_features.max(dim=1, keepdim=True)[0]  # Maximum über Dimension 1
    features_max = features_max.max(dim=2, keepdim=True)[0]      # Maximum über Dimension 2

    # Min-Max-Normalisierung der Features.
    features = (input_features - features_min) / (features_max - features_min + 1e-8)

    # Echte Face-Daten aus dem realen Mesh abrufen.
    real_faces = real_meshes["mesh"].faces_packed().to(device)
  
    # Edge-Index aus den Faces generieren.
    edge_index = edge_index_generator(real_faces).to(device)
    
    # Die Features vom Berechnungsgraphen abkoppeln.
    detached_features = features.detach()
    
    # Reale Meshes durch den Diskriminator verarbeiten.
    real_pred = discriminator(real_meshes["mesh"].verts_padded(), detached_features).to(device)
    real_pred = real_pred.to(device)
    
    # Batch-Größe wurde hier zu 1 geändert, da PyTorch3D den Batch in einen einzelnen Tensor packt.
    real_labels = torch.ones_like((real_pred)).to(device)  # Label 1 für reale Daten

    # Binäre Kreuzentropie als Verlustfunktion für reale Daten berechnen.
    real_loss = F.binary_cross_entropy(real_pred, real_labels).to(device)
    
    # Schritt 2: Generierte Daten durch den Diskriminator verarbeiten.
    z = torch.randn(batch_size, latent_dim)  # Zufälligen latenten Vektor erzeugen.
    generated_meshes = generator(features, z)  # Mit dem Generator ein Mesh erzeugen.

    # Vorhersage des Diskriminators für generierte Daten.
    fake_pred = discriminator(generated_meshes["mesh"].verts_padded(), detached_features).to(device)
    
    # Batch-Größe wurde hier zu 1 geändert, da PyTorch3D den Batch in einen Tensor packt.
    fake_labels = torch.zeros_like(fake_pred).to(device)  # Label 0 für generierte Daten
    
    # Verlust für generierte Daten berechnen.
    fake_loss = F.binary_cross_entropy(fake_pred, fake_labels).to(device)

    # Gesamten Diskriminator-Loss berechnen und Backpropagation durchführen.
    d_loss = real_loss + fake_loss.to(device)
    d_loss.backward()
    optimizer_D.step()
    
    # -----------------
    # Training des Generators
    # -----------------
    optimizer_G.zero_grad()
    
    # Schritt 3: Mit einem neuen Zufallsvektor ein neues Mesh erzeugen.
    z = torch.randn(batch_size, latent_dim)
    generated_meshes = generator(features, z)
    
    # Das generierte Mesh durch den Diskriminator verarbeiten.
    fake_pred = discriminator(generated_meshes["mesh"].verts_padded(), features).to(device)
    adv_loss = F.binary_cross_entropy(fake_pred, torch.ones_like(fake_pred)).to(device)

    # Aus dem generierten Mesh Punktwolken erzeugen.
    fake_point_clouds = sample_points_from_meshes(generated_meshes["mesh"], num_samples=num_verts).to(device)
    
    # Für die Normal Consistency: Die realen Punktwolken in ihre ursprüngliche Dimension zurückführen.
    real_point_clouds = point_clouds.permute(0, 2, 1)
    
    # Verlust für Normal Consistency berechnen (Glättung durch Konsistenz der Normalen).
    normal_loss = mesh_normal_consistency(generated_meshes["mesh"])

    # Chamfer-Loss zwischen den generierten und realen Punktwolken berechnen.
    chamfer_loss, _ = chamfer_distance(fake_point_clouds, real_point_clouds)
    print("c_loss: ", chamfer_loss)

    # Gesamter Generator-Loss: Kombination aus adversarial, Chamfer- und Normal Consistency-Loss.
    g_loss = adv_loss + chamfer_loss + 0.1 * normal_loss
    g_loss.backward()
    optimizer_G.step()

    # Ausgabe der Verluste für die aktuelle Epoche.
    print(f"Epoch [{epoch+1}/{num_epochs}]  Loss D: {d_loss.item():.4f}, Loss G: {g_loss.item():.4f}")
