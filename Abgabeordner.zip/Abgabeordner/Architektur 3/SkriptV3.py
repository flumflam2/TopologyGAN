#!/usr/bin/env python
# coding: utf-8


get_ipython().run_line_magic('matplotlib', 'inline')
get_ipython().run_line_magic('matplotlib', 'notebook')



# In[1]:
import os                              # Modul zur Arbeit mit Betriebssystempfaden und Dateien
import sys                             # Modul für Systemparameter und Funktionen
import numpy                           # Numerisches Rechnen (ohne Alias)


import torch                           # Hauptpaket von PyTorch für Tensoroperationen und Deep Learning
import torch.nn as nn                  # Modul zum Erstellen von neuronalen Netzwerkschichten
import torch.optim as optim            # Optimierungsalgorithmen (z. B. Adam)
import torch.utils.data                # Datenlade-Utilities von PyTorch
import torch.nn.functional as F        # Funktionale Schnittstelle für Aktivierungen, Verlustfunktionen etc.
from torch.utils.data import Dataset, DataLoader  # Dataset und DataLoader Klassen

from scipy.spatial import Delaunay      # Delaunay-Triangulation (für Mesh-Erzeugung)
from collections import OrderedDict      # Zum Umsortieren von state_dicts

import pymeshlab                       # Für die Vorverarbeitung von Meshes
from pytorch3d.ops import knn_points     # Für k-NN-Berechnungen in Punktwolken
from preprocess import find_neighbor     # Lokale Funktion zum Finden von Nachbarn in Meshes
from layers import SpatialDescriptor, StructuralDescriptor, MeshConvolution  # Lokale Module zur Feature-Extraktion

import open3d as o3d                   # Open3D für 3D-Punktwolken und Mesh-Rekonstruktion
import trimesh                         # Zum Laden von OFF-Dateien
from scipy.spatial import KDTree         # Schnelle Nachbarschaftssuche (z. B. für Vertex-Dichte)

from pytorch3d.io import save_obj        # Zum Exportieren von Meshes in OBJ-Dateien
from pytorch3d.loss import chamfer_distance  # Chamfer-Loss-Berechnung
from pytorch3d.io import load_objs_as_meshes  # Laden von Meshes aus OBJ-Dateien
from pytorch3d.ops import sample_points_from_meshes  # Zum Sampling von Punktwolken aus Meshes
from pytorch3d.utils import ico_sphere    # Zum Erzeugen von geodätischen Kugel-Meshes
from pytorch3d.ops import sample_points_from_meshes  # (doppelt importiert, bleibt erhalten)
from pytorch3d.structures import Meshes   # Zum Erzeugen und Verwalten von Meshes-Objekten
from pytorch3d.io import load_obj, save_obj  # load_obj und save_obj (save_obj wird hier erneut importiert)
from pytorch3d.datasets import collate_batched_meshes,  \
    R2N2, ShapeNetCore, render_cubified_voxels  # Import aus pytorch3d.datasets (meistens unbenutzt)



from dgcnn_model import DGCNN           # Lokales Modul für das DGCNN-Modell


# In[2]:
import os
import torch
import torch.nn as nn
import torch.nn.functional as Fu   # Beachte: "Fu" wird hier anstelle von "F" verwendet
from torch.utils.data import Dataset, DataLoader

# PyTorch3D-Importe für das Handling von Meshes und I/O.
from pytorch3d.structures import Meshes
from pytorch3d.io import load_objs_as_meshes

# =============================================================================
# 1. Datensatz und DataLoader
# =============================================================================
import os
import torch
from torch.utils.data import Dataset
from pytorch3d.io import load_objs_as_meshes

class MeshDataset(Dataset):
    """
    Ein Dataset, das passende Mesh-Paare aus zwei Ordnern lädt.
    Es wird davon ausgegangen, dass beide Ordner OBJ-Dateien mit identischen Namen (oder sortierter Reihenfolge) enthalten.
    Beispiel: "mesh_000.obj" im Ordner mit schlechter Topologie entspricht "mesh_000.obj" im Ordner mit guter Topologie.
    """
    def __init__(self, bad_folder, good_folder, device=None):
        """
        Args:
            bad_folder (str): Pfad zum Ordner mit Meshes schlechter Topologie.
            good_folder (str): Pfad zum Ordner mit Meshes guter Topologie.
            device (torch.device, optional): Gerät, auf dem die Meshes geladen werden.
        """
        self.bad_folder = bad_folder
        self.good_folder = good_folder

        # Dateien auflisten und sortieren (die Namenskonvention wird vorausgesetzt, um die Dateien zuzuordnen)
        self.bad_files = sorted([os.path.join(bad_folder, f)
                                 for f in os.listdir(bad_folder) if f.endswith('.obj')])
        self.good_files = sorted([os.path.join(good_folder, f)
                                  for f in os.listdir(good_folder) if f.endswith('.obj')])
        
        # Sicherstellen, dass beide Ordner gleich viele Dateien enthalten.
        assert len(self.bad_files) == len(self.good_files), "Anzahl der Dateien in den Ordnern stimmt nicht überein"
        
        self.device = device if device is not None else \
                      torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    def __len__(self):
        return len(self.bad_files)

    def __getitem__(self, idx):
        # Lade das "schlechte" Mesh und das entsprechende "gute" Mesh.
        # load_objs_as_meshes gibt ein Meshes-Objekt mit Batch-Größe 1 zurück.
        bad_mesh = load_objs_as_meshes([self.bad_files[idx]], device=self.device, load_textures=False)
        good_mesh = load_objs_as_meshes([self.good_files[idx]], device=self.device, load_textures=False)

        bad_faces, bad_verts = convert_tris_to_quads(bad_mesh)
        good_faces, good_verts = convert_tris_to_quads(good_mesh)
        # Normalisiere die Vertices.
        bad_verts_norm = normalize_vertices(bad_verts)
        good_verts_norm = normalize_vertices(good_verts)
        # Erzeuge und gebe ein neues Meshes-Objekt mit normalisierten Vertices zurück.
        normalized_bad_mesh = Meshes(verts=[bad_verts_norm], faces=[bad_faces])
        normalized_good_mesh = Meshes(verts=[good_verts_norm], faces=[good_faces])
        
        return normalized_bad_mesh, normalized_good_mesh

def convert_tris_to_quads(mesh):
    """
    Konvertiert ein PyTorch3D Mesh (mit triangulierten Faces) in einen einzelnen Face-Tensor,
    der sowohl Quad- als auch Dreiecksfaces enthält. Dreiecksfaces werden durch Wiederholen
    des letzten Vertex gepolstert, sodass alle Faces vier Indizes haben.
    
    Args:
        mesh (pytorch3d.structures.Meshes): Das PyTorch3D Mesh-Objekt.
        device (str): Das Gerät, auf das die Ausgabe-Tensoren übertragen werden.
    
    Returns:
        faces (torch.Tensor): Tensor mit Face-Indizes der Form (F, 4). Bei Dreiecksfaces wird der letzte Index wiederholt.
        verts (torch.Tensor): Tensor der Vertex-Positionen der Form (V, 3).
    """
    # Extrahiere Vertices und Dreiecksfaces.
    verts = mesh.verts_list()[0]      # (V, 3)
    tri_faces = mesh.faces_list()[0]    # (F, 3)

    # Baue eine Zuordnung von jedem sortierten Edge zu den Dreiecksface-Indizes, die diesen Edge enthalten.
    edge_to_faces = {}
    for i, face in enumerate(tri_faces):
        edges = [
            (face[0].item(), face[1].item()),
            (face[1].item(), face[2].item()),
            (face[2].item(), face[0].item()),
        ]
        for edge in edges:
            edge = tuple(sorted(edge))
            edge_to_faces.setdefault(edge, []).append(i)

    # Fasse benachbarte Dreiecke zu Quads zusammen, wenn möglich.
    used_tris = set()
    merged_quads = []
    for edge, faces in edge_to_faces.items():
        if len(faces) == 2:
            f1, f2 = faces
            if f1 in used_tris or f2 in used_tris:
                continue  # Bereits zu einem Quad zusammengefasst.
            # Kombiniere die Vertices beider Dreiecke.
            verts_f1 = tri_faces[f1].tolist()
            verts_f2 = tri_faces[f2].tolist()
            unique_vertices = list(set(verts_f1 + verts_f2))
            if len(unique_vertices) == 4:
                merged_quads.append(unique_vertices)
                used_tris.update([f1, f2])

    # Für Dreiecke, die nicht zusammengeführt wurden, polstere sie auf 4 Vertices auf.
    remaining_tris = []
    for i in range(len(tri_faces)):
        if i not in used_tris:
            tri = tri_faces[i].tolist()
            padded_tri = tri + [tri[-1]]  # Wiederhole den letzten Vertex zum Auffüllen.
            remaining_tris.append(padded_tri)

    # Kombiniere zusammengeführte Quads und gepolsterte Dreiecke.
    all_faces = merged_quads + remaining_tris
    faces_tensor = torch.tensor(all_faces, dtype=torch.long, device=device)
    verts = verts.to(device)

    return faces_tensor, verts


def export_mesh_to_obj(verts, faces, filename):
    """
    Exportiert ein Mesh in eine OBJ-Datei.
    
    Args:
        verts (Tensor): Ein Tensor (V, 3) mit den Vertex-Positionen.
        faces (Tensor): Ein Tensor (F, N) mit Face-Indizes (N = 3 für Dreiecke, 4 für Quads usw.).
        filename (str): Ausgabepfad der Datei.
    """
    with open(filename, "w") as f:
        # Schreibe die Vertex-Daten.
        for v in verts:
            f.write(f"v {v[0].item()} {v[1].item()} {v[2].item()}\n")
        # Schreibe die Face-Daten (OBJ-Format ist 1-indexiert).
        for face in faces:
            face_idx = [str(int(idx.item()) + 1) for idx in face]
            f.write("f " + " ".join(face_idx) + "\n")
    print(f"Mesh exportiert nach {filename}")

def normalize_vertices(verts):
    """
    Normalisiert die Vertices so, dass das Mesh in allen Richtungen in [-1, 1] passt,
    während die Proportionen erhalten bleiben.
    """
    # Berechne das Zentrum der Vertices.
    center = verts.mean(dim=0, keepdim=True)
    verts_centered = verts - center

    # Finde den maximalen absoluten Wert über alle Achsen.
    max_val = verts_centered.abs().max()
    # Vermeide Division durch Null.
    if max_val == 0:
        max_val = 1.0
    # Skaliere die Vertices gleichmäßig.
    verts_norm = verts_centered / max_val
    return verts_norm

def collate_meshes(batch):
    """
    Fasst eine Liste von (bad_mesh, good_mesh)-Tupeln zu einem Tupel von gebatchten Meshes zusammen:
    (gebatchte_bad_meshes, gebatchte_good_meshes).
    
    Args:
        batch (Liste[Tuple[Meshes, Meshes]]): Jedes Element ist ein Tupel, das zwei Meshes-Objekte enthält.
        
    Returns:
        Tuple[Meshes, Meshes]: Gebatchte Meshes für schlechte und gute Meshes.
    """
    # Jeder Eintrag im Batch ist ein Tupel (bad_mesh, good_mesh).
    # Extrahiere die Vertex- und Face-Listen aus jedem Meshes-Objekt.
    bad_verts = [sample[0].verts_list()[0] for sample in batch]
    bad_faces = [sample[0].faces_list()[0] for sample in batch]
    good_verts = [sample[1].verts_list()[0] for sample in batch]
    good_faces = [sample[1].faces_list()[0] for sample in batch]
    
    batched_bad_meshes = Meshes(verts=bad_verts, faces=bad_faces)
    batched_good_meshes = Meshes(verts=good_verts, faces=good_faces)
    return batched_bad_meshes, batched_good_meshes


# New Generator
# ==============
#
# Dieser Abschnitt definiert den neuen Generator, der aus den global extrahierten Features
# die Vertex-Positionen des generierten Meshes vorhersagt.
# 

# In[3]:
class GraphConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(GraphConv, self).__init__()
        self.linear = nn.Linear(in_channels, out_channels)
        
    def forward(self, x, edge_index):
        """
        Args:
            x: Tensor der Form (V, in_channels) – per-Vertex-Features.
            edge_index: Tensor der Form (2, E), wobei jede Spalte (Quelle, Ziel) repräsentiert.
        Returns:
            Tensor der Form (V, out_channels).
        """
        V = x.size(0)
        # Importiere torch_scatter lokal zur Aggregation von Nachrichten aus den Nachbarn.
        import torch_scatter
        src = edge_index[0]   # Quell-Vertices (E,)
        target = edge_index[1]  # Ziel-Vertices (E,)
        messages = x[src]       # Nachrichten von den Quell-Vertices, Form: (E, in_channels)
        # Aggregiere (Mittelwert) die Nachrichten für jeden Ziel-Vertex.
        agg = torch_scatter.scatter_mean(messages, target, dim=0, dim_size=V)
        return self.linear(agg)

# -------------------------------
# Hilfsfunktion: Berechnung des Edge-Index aus Faces
# -------------------------------
def compute_edge_index(face_list):
    """
    Gegeben eine Liste von Faces (jedes Face ist ein Tensor oder eine Liste von Vertex-Indizes),
    berechnet diese Funktion einen Edge-Index-Tensor (2, E). Für jedes Face bilden aufeinanderfolgende
    Vertices (einschließlich der Verbindung vom letzten zum ersten) ungerichtete Kanten.
    """
    edges = []
    for face in face_list:
        # Falls nötig in eine Liste umwandeln.
        face_list_val = face.tolist() if isinstance(face, torch.Tensor) else face
        num_slots = len(face_list_val)
        for j in range(num_slots):
            src = face_list_val[j]
            tgt = face_list_val[(j + 1) % num_slots]
            edges.append((src, tgt))
            edges.append((tgt, src))  # ungerichtete Kante
    if len(edges) > 0:
        edge_index = torch.tensor(edges, dtype=torch.long)
        edge_index = edge_index.t().contiguous()  # Form: (2, E)
    else:
        edge_index = torch.empty((2, 0), dtype=torch.long)
    return edge_index

# -------------------------------
# Angepasster MeshGenerator-Modul
# -------------------------------
class MeshGenerator(nn.Module):
    def __init__(self, hidden_dim=64, tau=1.0):
        super(MeshGenerator, self).__init__()
        self.hidden_dim = hidden_dim
        self.tau = tau

        # Initialer per-Vertex-Feature-Extraktor.
        self.vertex_mlp = nn.Sequential(
            nn.Linear(3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Graph-Convolution-Schicht zur Integration des lokalen Nachbarschaftskontexts.
        self.graph_conv = GraphConv(hidden_dim, hidden_dim)
        
        # Vorhersage von Vertex-Offsets (initial nahe null).
        self.offset_mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 3)
        )
        nn.init.constant_(self.offset_mlp[-1].weight, 0.0)
        nn.init.constant_(self.offset_mlp[-1].bias, 0.0)
        
        # Gemeinsamer Prädiktor für die Face-Konnektivität.
        # Nimmt die konkatenierte Face- und ursprüngliche Vertex-Feature (Größe: 2*hidden_dim) und liefert einen Query-Vektor (Größe: hidden_dim).
        self.shared_face_predictor = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
    def forward(self, meshes: Meshes):
        
        new_verts_list = []
        new_faces_list = []
        
        # Verarbeite jedes Mesh im Batch.
        for verts, faces in zip(meshes.verts_list(), meshes.faces_list()):
            # verts: (V, 3)
            V = verts.shape[0]
            
            # Berechne per-Vertex-Features.
            v_feats = self.vertex_mlp(verts)  # Form: (V, hidden_dim)
            # Graph-basierte Aggregation der Features.
            edge_index = compute_edge_index(faces)  # Berechne Edge-Index aus der Face-Konnektivität.
            edge_index = edge_index.to(device)
            # Verfeinere die Vertex-Features durch Addition der aggregierten Informationen.
            refined_feats = v_feats + self.graph_conv(v_feats, edge_index)  # (V, hidden_dim)
            
            # Sage Vertex-Offsets basierend auf den verfeinerten Features vorher.
            offsets = self.offset_mlp(refined_feats)  # (V, 3)
            new_verts = verts + offsets               # Aktualisierte Vertex-Positionen: (V, 3)
            
            # Verarbeite die Konnektivität: new_face_indices enthält die neue Face-Konnektivität.
            new_face_indices = []
            for idx, face in enumerate(faces):
                # Jedes Face ist ein Tensor (oder Liste) von Vertex-Indizes; die Anzahl der Elemente kann variieren.
                num_slots = face.shape[0]
                # Berechne ein Face-Level-Feature als Mittelwert der verfeinerten Vertex-Features.
                face_v_feats = refined_feats[face]  # (num_slots, hidden_dim)
                face_feat = face_v_feats.mean(dim=0, keepdim=True)  # (1, hidden_dim)
                new_face = []
                for i in range(num_slots):
                    # Hole das ursprüngliche Vertex-Feature für den Slot i.
                    orig_v_feat = refined_feats[face[i]].unsqueeze(0)  # (1, hidden_dim)
                    # Konkatenieren des Face-Level-Features mit dem ursprünglichen Vertex-Feature.
                    combined_feat = torch.cat([face_feat, orig_v_feat], dim=1)  # (1, 2*hidden_dim)
                    # Berechne den Query-Vektor mittels shared_face_predictor.
                    query = self.shared_face_predictor(combined_feat)  # (1, hidden_dim)
                    
                    # --- k-NN-Einschränkung zur Reduzierung des Kandidatensatzes ---
                    # Verwende die ursprüngliche Vertex-Position als Referenz.
                    ref_point = verts[face[i]].unsqueeze(0)  # (1, 3)
                    query_points = ref_point.unsqueeze(1)     # (1, 1, 3)
                    verts_expanded = verts.unsqueeze(0)         # (1, V, 3)
                    # Verwende K=2 (anpassbar).
                    knn_out = knn_points(query_points, verts_expanded, K=2)
                    # knn_out.idx hat die Form (1, 1, K) → squeeze zu (1, K)
                    knn_indices = knn_out.idx.squeeze(1)  # (1, K)
                    
                    # Sammle Kandidaten-Features aus den verfeinerten Features.
                    candidate_features = refined_feats[knn_indices]  # (1, K, hidden_dim)
                    
                    # --- Berechne Kandidaten-Scores ---
                    query_unsq = query.unsqueeze(1)  # (1, 1, hidden_dim)
                    candidate_scores = torch.bmm(query_unsq, candidate_features.transpose(1, 2)).squeeze(1)  # (1, K)
                    
                    # --- Biasing ---
                    # Erzeuge eine Maske: Überprüfe, ob der Kandidat dem ursprünglichen Vertex-Index entspricht.
                    match = (knn_indices == face[i].unsqueeze(0))  # (1, K), boolesch
                    bias = torch.where(match, torch.tensor(3.0, device=verts.device),
                                         torch.tensor(-1.0, device=verts.device))
                    candidate_scores = candidate_scores + bias
                    
                    # --- Differenzierbare Auswahl (Gumbel-Softmax) ---
                    face_slot_onehot = F.gumbel_softmax(candidate_scores, tau=self.tau, hard=True, dim=1)  # (1, K)
                    chosen_idx_in_candidates = face_slot_onehot.argmax(dim=1)  # (1,)
                    # Mappe zurück auf den tatsächlichen Vertex-Index.
                    chosen_idx = knn_indices[0, chosen_idx_in_candidates.item()]
                    new_face.append(chosen_idx)
                # Wandle die Liste der neuen Face-Indizes in einen Tensor um.
                new_face_tensor = torch.tensor(new_face, device=verts.device)
                new_face_indices.append(new_face_tensor)
            new_verts_list.append(new_verts)
            new_faces_list.append(new_face_indices)
        if len(new_faces_list) == 1 and isinstance(new_faces_list[0], list):
            faces_inner = new_faces_list[0]
        else:
            faces_inner = new_faces_list

        # Wandle jedes Face von einer Liste von Tensors in eine Liste von Integern um.
        faces_list = []
        if isinstance(faces_inner[0], list):
            for mesh_faces in faces_inner:
                for face in mesh_faces:
                    new_face = [int(v.item()) for v in face]
                    faces_list.append(new_face)
        else:
            for face in faces_inner:
                new_face = [int(v.item()) for v in face]
                faces_list.append(new_face)

        new_faces_list_out = []
        for mesh_faces in new_faces_list:
            faces_tensor = torch.stack([face.long() for face in mesh_faces], dim=0)
            new_faces_list_out.append(faces_tensor)

        # Gib ein Meshes-Objekt zurück mit den aktualisierten Vertices und der beibehaltenen Konnektivität.
        return Meshes(verts=new_verts_list, faces=new_faces_list_out)


# New Discriminator
# =================
#
# Der neue Diskriminator nimmt ein Paar von Meshes entgegen:
#  - candidate: das zu bewertende Mesh (generiert oder real mit guter Topologie)
#  - reference: das Referenz-Mesh mit guter Topologie
#
# Ziel ist es, die globale Topologie zu extrahieren und mittels eines Klassifikators zu bewerten.
# 

# In[4]:
class GraphConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(GraphConv, self).__init__()
        self.linear = nn.Linear(in_channels, out_channels)
        
    def forward(self, x, edge_index):
        """
        Args:
            x: Tensor der Form (V, in_channels) – per-Vertex-Features.
            edge_index: Tensor der Form (2, E), wobei jede Spalte (Quelle, Ziel) repräsentiert.
        Returns:
            Tensor der Form (V, out_channels) mit aggregierten Nachbar-Features.
        """
        V = x.size(0)
        # Führe eine einfache Mittelwertaggregation über die Nachbarn durch.
        agg = torch.zeros_like(x)
        count = torch.zeros(V, device=x.device)
        # edge_index[0] enthält die Quell-Vertices, edge_index[1] die Ziel-Vertices.
        for src, tgt in edge_index.t():
            agg[tgt] += x[src]
            count[tgt] += 1
        # Vermeide Division durch Null.
        count = count.unsqueeze(1).clamp(min=1)
        agg = agg / count
        return self.linear(agg)

# -------------------------------
# Hilfsfunktion: Berechnung des Edge-Index aus Faces
# -------------------------------
def compute_edge_index(faces):
    """
    Gegeben einen Tensor von Faces der Form (F, num_slots) (z. B. (F,3) für Dreiecke oder (F,4) für Quads),
    berechnet diese Funktion einen Edge-Index-Tensor (2, E). Für jedes Face bilden aufeinanderfolgende
    Vertices (einschließlich des letzten, der mit dem ersten verbunden wird) ungerichtete Kanten.
    """
    F, num_slots = faces.shape
    edges = []
    for f in range(F):
        face = faces[f]
        for i in range(num_slots):
            src = face[i].item()
            tgt = face[(i+1) % num_slots].item()
            edges.append((src, tgt))
            edges.append((tgt, src))
    if len(edges) > 0:
        edge_index = torch.tensor(edges, dtype=torch.long, device=faces.device)
        edge_index = edge_index.t().contiguous()
    else:
        edge_index = torch.empty((2, 0), dtype=torch.long, device=faces.device)
    return edge_index

# -------------------------------
# Angepasster MeshDiscriminator-Modul
# -------------------------------
class MeshDiscriminator(nn.Module):
    """
    Ein konditionaler Diskriminator, der ein Paar von Meshes entgegennimmt:
      - candidate: das zu bewertende Mesh (generiert oder real mit guter Topologie)
      - reference: das Referenz-Mesh mit guter Topologie.
      
    Dieser Diskriminator fokussiert sich auf die Topologie, indem er Vertex-Features mittels
    Graph-Convolution basierend auf der Konnektivität des Meshes verfeinert.
    """
    def __init__(self, hidden_dim=64):
        super(MeshDiscriminator, self).__init__()
        self.hidden_dim = hidden_dim
        
        # Gemeinsamer per-Vertex-Feature-Extraktor.
        self.vertex_mlp = nn.Sequential(
            nn.Linear(3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Graph-Convolution-Schicht zur Integration der Nachbarschaftskonnektivität.
        self.graph_conv = GraphConv(hidden_dim, hidden_dim)
        
        # Verarbeitung der Face-Features.
        self.face_mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # Globale Projektion.
        self.global_mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # Finaler Klassifikator: Kombination der globalen Topologie-Features von candidate und reference.
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
        
    def extract_global_feature(self, mesh: Meshes):
        """
        Extrahiert einen globalen Feature-Vektor aus einem Mesh basierend hauptsächlich auf seiner Konnektivität.
        Es wird angenommen, dass das Mesh als Batch mit einem Element vorliegt.
        """
        verts = mesh.verts_list()[0]  # (V, 3)
        faces = mesh.faces_list()[0]  # (F, num_slots)
        
        v_feats = self.vertex_mlp(verts)  # (V, hidden_dim)
        edge_index = compute_edge_index(faces)  # (2, E)
        refined_feats = v_feats + self.graph_conv(v_feats, edge_index)  # (V, hidden_dim)
        
        # Sammle für jedes Face die verfeinerten Vertex-Features.
        refined_face_feats = refined_feats[faces]
        # Aggregiere Face-Features durch Mittelung über die Vertices.
        face_feats = refined_face_feats.mean(dim=1)  # (F, hidden_dim)
        face_feats = self.face_mlp(face_feats)         # Weiterverarbeitung.
        # Globales Feature: Durchschnitt über alle Faces.
        global_feat = face_feats.mean(dim=0)  # (hidden_dim,)
        global_feat = self.global_mlp(global_feat)
        return global_feat
    
    def forward(self, candidate_meshes: Meshes, ref_meshes: Meshes):
        """
        Für jedes Mesh-Paar (candidate, reference) werden globale Topologie-Features extrahiert und
        mittels des Klassifikators bewertet, ob das candidate-Mesh gute Topologie aufweist.
        """
        batch_size = len(candidate_meshes.verts_list())
        cand_features = []
        ref_features = []
        for cand_mesh, ref_mesh, cand_faces, ref_faces in zip(
                candidate_meshes.verts_list(),
                ref_meshes.verts_list(),
                candidate_meshes.faces_list(),
                ref_meshes.faces_list()):
            cand = Meshes(verts=[cand_mesh], faces=[cand_faces])
            ref  = Meshes(verts=[ref_mesh],  faces=[ref_faces])
            cand_features.append(self.extract_global_feature(cand))
            ref_features.append(self.extract_global_feature(ref))
        cand_features = torch.stack(cand_features, dim=0)
        ref_features  = torch.stack(ref_features, dim=0)
        combined = torch.cat([cand_features, ref_features], dim=1)
        out = self.classifier(combined)
        return out


# New Loss Functions
# ===================
#
# Hier werden neue Verlustfunktionen definiert.
# 

# In[5]:
def convexity_loss(verts, faces, tol=0.0):
    """
    Berechnet einen Konvexitätsverlust für ein einzelnes Mesh.
    
    Args:
        verts (Tensor): (V, 3) Tensor der Vertex-Positionen.
        faces (Tensor): (F, 3) Tensor der Face-Indizes (für Dreiecke).
        tol (float): Toleranz; Werte oberhalb werden als gültig betrachtet.
        
    Returns:
        Tensor: Ein skalare Verlustwert. Null, wenn jeder Vertex auf oder außerhalb jedes Faces liegt.
    """
    v0 = verts[faces[:, 0]]
    v1 = verts[faces[:, 1]]
    v2 = verts[faces[:, 2]]
    
    face_center = (v0 + v1 + v2) / 3.0
    face_normal = torch.cross(v1 - v0, v2 - v0)
    face_normal = F.normalize(face_normal, dim=1)
    
    diff = verts.unsqueeze(0) - face_center.unsqueeze(1)
    dot = torch.sum(diff * face_normal.unsqueeze(1), dim=2)
    penalty = F.relu(tol - dot)
    loss = penalty.mean()
    return loss


# New Training
# =============
#
# Hier beginnt das Training des Modells.
# 

# In[ ]:
num_epochs = 30
lambda_chamfer = 1
lambda_convexity = 1
batch_size = 4

bad_folder = "/badTopo"    # Pfad zum Ordner mit Meshes schlechter Topologie
good_folder = "/goodTopo"  # Pfad zum Ordner mit Meshes guter Topologie

# Erstelle Dataset und DataLoader
dataset = MeshDataset(bad_folder, good_folder)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_meshes)

# Initialisiere Modelle und setze sie auf das jeweilige Gerät.
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)

generator = MeshGenerator(hidden_dim=64, tau=1).to(device)
discriminator = MeshDiscriminator(hidden_dim=64).to(device)

# Setze Optimierer
optimizer_g = optim.Adam(generator.parameters(), lr=1e-4)
optimizer_d = optim.Adam(discriminator.parameters(), lr=1e-4)

# Definiere die adversarial Loss-Funktion.
adversarial_loss = nn.BCELoss()

for epoch in range(num_epochs):
    for i, (bad_meshes, good_meshes) in enumerate(dataloader):
        bad_meshes = bad_meshes.to(device)
        good_meshes = good_meshes.to(device)
        batch_size = len(bad_meshes.verts_list())

        valid = torch.ones((batch_size, 1), device=device)
        fake = torch.zeros((batch_size, 1), device=device)
        
        # -------------------------
        # Training des Diskriminators
        # -------------------------
        optimizer_d.zero_grad()
        
        # Reale Paare: Der Diskriminator sieht (good, good)
        pred_real = discriminator(good_meshes, good_meshes)
        loss_real = adversarial_loss(pred_real, valid)

        # Generiere gefälschte Meshes; detach, um Gradienten nicht an den Generator weiterzugeben.
        fake_meshes = generator(bad_meshes)
        fake_meshes_detached = fake_meshes.detach()
        pred_fake = discriminator(fake_meshes_detached, good_meshes)
        loss_fake = adversarial_loss(pred_fake, fake)
        
        loss_d = (loss_real + loss_fake) / 2
        loss_d.backward()
        optimizer_d.step()
        
        # -------------------------
        # Training des Generators
        # -------------------------
        optimizer_g.zero_grad()
        
        # Berechne gefälschte Meshes erneut, damit der Graph des Generators erhalten bleibt.
        fake_meshes_for_gen = generator(bad_meshes)
        pred_fake_for_g = discriminator(fake_meshes_for_gen, good_meshes)
        loss_g_adv = adversarial_loss(pred_fake_for_g, valid)

        # Berechne Chamfer-Loss, um die Form beizubehalten (Vergleich mit good_meshes)
        chamfer_loss_total = 0.0
        fake_verts_list = fake_meshes_for_gen.verts_list()
        good_verts_list = good_meshes.verts_list()
        for fake_verts, good_verts in zip(fake_verts_list, good_verts_list):
            loss, _ = chamfer_distance(fake_verts.unsqueeze(0), good_verts.unsqueeze(0))
            chamfer_loss_total += loss
        chamfer_loss = chamfer_loss_total / len(fake_verts_list)

        convexity_loss_total = 0.0
        for verts, faces in zip(fake_meshes_for_gen.verts_list(), fake_meshes_for_gen.faces_list()):
            convexity_loss_total += convexity_loss(verts, faces, tol=0.0)
        convexity_loss_avg = convexity_loss_total / len(fake_meshes_for_gen.verts_list
